# PyDistances

`PyDistances` is a `Python` package for computing classic statistical distances as well as new proposals suitable for mixed multivariate data, even with outliers.

The theoretical aspects regarding the package and specially the new proposed distances can be found in the following Master’s Thesis, written by Fabio Scielzo Ortiz: [TO DO]

